﻿print("ok")
function 我(){
	print("ok")
}
